package com.lepu.pc_700.helper;

/**
 * Sample相关的常量定义类
 */
public class PushConstants {
    /**
     * 应用申请的Appkey
     */
//    public static final String APP_KEY = "应用申请的Appkey";
    public static final String APP_KEY = "6119b2ef6aac3162c7ed1bbd";

    /**
     * 应用申请的UmengMessageSecret
     */
//    public static final String MESSAGE_SECRET = "应用申请的UmengMessageSecret";
    public static final String MESSAGE_SECRET = "31c85ab632e0f2d1f117b3012e29e12a";

    /**
     * 后台加密消息的密码（仅Demo用，请勿将此密码泄漏）
     */
    public static final String APP_MASTER_SECRET = "qdtkrixyfwzxctowjvn0oinkx6t7k7i5";

    /**
     * 渠道名称，修改为您App的发布渠道名称
     */
    public static final String CHANNEL = "Umeng";

    /**
     * 小米后台APP对应的xiaomi id
     */
//    public static final String MI_ID = "填写您在小米后台APP对应的xiaomi id";
    //public static final String MI_ID = "";

    /**
     * 小米后台APP对应的xiaomi key
     */
//    public static final String MI_KEY = "填写您在小米后台APP对应的xiaomi key";
   // public static final String MI_KEY = "";

    /**
     * 魅族后台APP对应的xiaomi id
     */
//    public static final String MEI_ZU_ID = "填写您在魅族后台APP对应的app id";
   // public static final String MEI_ZU_ID = "";

    /**
     * 魅族后台APP对应的xiaomi key
     */
//    public static final String MEI_ZU_KEY = "填写您在魅族后台APP对应的app key";
  //  public static final String MEI_ZU_KEY = "";

    /**
     * OPPO后台APP对应的app key
     */
//    public static final String OPPO_KEY = "填写您在OPPO后台APP对应的app key";
    //public static final String OPPO_KEY = "";

    /**
     * OPPO后台APP对应的app secret
     */
//    public static final String OPPO_SECRET = "填写您在OPPO后台APP对应的app secret";
    //public static final String OPPO_SECRET = "";
}
