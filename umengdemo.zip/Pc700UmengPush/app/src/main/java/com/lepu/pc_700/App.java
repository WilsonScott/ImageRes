package com.lepu.pc_700;

import android.app.Application;

import com.lepu.pc_700.helper.PushHelper;
import com.umeng.commonsdk.UMConfigure;

/**
 * Package Name:com.lepu.pc_700
 * <p>
 * Created by: lipeng
 * <p>
 * Date: 2021 - 08 - 13
 * <p>
 * Description:
 */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //日志开关
        UMConfigure.setLogEnabled(true);
        //预初始化
        PushHelper.preInit(this);
        new Thread(new Runnable() {
            @Override
            public void run() {
                PushHelper.init(getApplicationContext());
            }
        }).start();
    }
}
